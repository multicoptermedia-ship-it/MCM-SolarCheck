from pathlib import Path
from io import BytesIO
from hashlib import sha256
import zipfile,json,pickletools,sys
p=Path(sys.argv[1])
if not p.is_file() or not 1<=p.stat().st_size<=80_000_000:raise ValueError('Bounded public model archive required')
result=dict(check='solarcheck-cvut-yolo-inventory-1',source_url='https://imr.ciirc.cvut.cz/uploads/Datasets/PV_YOLOv8_models.zip',archive_bytes=p.stat().st_size,archive_sha256=sha256(p.read_bytes()).hexdigest(),checksum_kind='locally_observed_not_publisher_verified',entries=[],model_loaded=False,inference_started=False,training_started=False,production_approved=False)
with zipfile.ZipFile(p) as z:
 es=z.infolist()
 if len(es)>80 or sum(e.file_size for e in es)>250_000_000:raise ValueError('Unexpected archive expansion')
 for e in es:
  row=dict(name=e.filename,bytes=e.file_size,compressed_bytes=e.compress_size)
  if e.is_dir():result['entries'].append(row);continue
  if e.file_size>80_000_000 or '..' in Path(e.filename).parts or Path(e.filename).is_absolute():raise ValueError('Unsafe archive member')
  if e.filename.lower().endswith(('.pt','.pth','.onnx')):
   data=z.read(e);row['sha256']=sha256(data).hexdigest()
   if e.filename.lower().endswith(('.pt','.pth')) and zipfile.is_zipfile(BytesIO(data)):
    with zipfile.ZipFile(BytesIO(data)) as q:
     meta=[i for i in q.infolist() if i.filename.endswith('/data.pkl') or i.filename=='data.pkl']
     if len(meta)!=1 or meta[0].file_size>4_000_000:raise ValueError('Unexpected Torch archive metadata')
     globals_seen=set();strings=set();opcount=0
     for op,arg,pos in pickletools.genops(q.read(meta[0])):
      opcount+=1
      if opcount>500_000:raise ValueError('Too many metadata operations')
      if op.name=='GLOBAL':globals_seen.add(arg)
      if op.name in ('BINUNICODE','SHORT_BINUNICODE','UNICODE') and isinstance(arg,str) and arg in ('names','nc','imgsz','train_args','model','version','date','license'):strings.add(arg)
     row['pickle_global_names_lexical_only']=sorted(globals_seen);row['recognized_metadata_keys']=sorted(strings)
  result['entries'].append(row)
print(json.dumps(result,indent=2));Path('/tmp/solarcheck-cvut-yolo-inventory.json').write_text(json.dumps(result,indent=2)+'\n')
