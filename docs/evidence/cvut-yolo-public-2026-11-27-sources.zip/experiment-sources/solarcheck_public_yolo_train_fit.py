from pathlib import Path
import json,time,sys
sys.path.insert(0,'/tmp')
from solarcheck_yolo_known_loss_probe import KnownPixelLoss
prefix=Path('/tmp/solarcheck_public_cvut_yolo_probe.py').read_text().split('scores=[];rows=[];started=')[0]
exec(compile(prefix,'public_yolo_probe_helpers','exec'))
from ultralytics.cfg import get_cfg
from mcm_solarcheck.services import pvis_controlled_learning as learning
model.args=get_cfg();torch.manual_seed(6400)
original={name:p.requires_grad for name,p in model.named_parameters()}
for name,p in model.named_parameters():p.requires_grad_(original[name] and name.startswith('model.22.'))
for layer in model.modules():
 if isinstance(layer,torch.nn.BatchNorm2d):
  for p in layer.parameters():p.requires_grad_(False)
criterion=KnownPixelLoss(model);optimizer=torch.optim.AdamW([p for p in model.parameters() if p.requires_grad],lr=.0001,weight_decay=.0001,foreach=False)
out=Path('/tmp/solarcheck-public-cvut-yolo/finetune-head');out.mkdir(exist_ok=True);history=[];best=-1;best_epoch=0;start=time.monotonic();ignore_verified=True
frozen={k:v.clone() for k,v in model.state_dict().items() if not k.startswith('model.22.') or 'running_' in k or 'num_batches_tracked' in k}
def batch(index,step):
 image,target=learning.augment(rgb[index],targets[index],step);image=torch.from_numpy(image.transpose(2,0,1).copy()).float().div(255).unsqueeze(0);ids=np.unique(target[target>0]);labels=np.zeros_like(target);boxes=[]
 for j,identity in enumerate(ids,1):
  y,x=np.nonzero(target==identity);labels[target==identity]=j;boxes.append([(x.min()+x.max()+1)/512,(y.min()+y.max()+1)/512,(x.max()+1-x.min())/256,(y.max()+1-y.min())/256])
 return dict(img=image,batch_idx=torch.zeros(len(ids)),cls=torch.zeros((len(ids),1)),bboxes=torch.tensor(boxes,dtype=torch.float32),masks=torch.from_numpy(labels.copy()).unsqueeze(0).float()),torch.from_numpy((target>=0).copy()).unsqueeze(0)
def evaluate():
 model.eval();results=[];rows=[]
 with torch.inference_mode():
  for i,row in enumerate(manifest['samples']):
   if row['split']!='validation':continue
   x=torch.from_numpy(rgb[i].transpose(2,0,1).copy()).float().div(255).unsqueeze(0);r=model(x);det=ops.non_max_suppression(r[0],conf_thres=.25,iou_thres=.7,nc=1,max_det=300,max_time_img=10)[0]
   masks=ops.process_mask_native(r[1][-1][0],det[:,6:],det[:,:4],(256,256)).numpy().astype(bool) if len(det) else np.zeros((0,256,256),bool);masks=masks[masks.any((1,2))];m=score(targets[i],masks);results.append(m);rows.append(dict(crop=len(rows)+1,**m))
 return aggregate(results),rows

model.load_state_dict(torch.load(out/'best-head-state.pt',map_location='cpu',weights_only=True),strict=True)
manifest['samples']=[dict(row,split='validation' if row['split']=='train' and i<8 else 'skip') for i,row in enumerate(manifest['samples'])]
print(json.dumps(evaluate()[0],indent=2))
