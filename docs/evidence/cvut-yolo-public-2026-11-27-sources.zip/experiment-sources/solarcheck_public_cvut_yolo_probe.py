from pathlib import Path
import json,time
import numpy as np,cv2,torch
from ultralytics.nn.tasks import SegmentationModel
from ultralytics.utils import yaml_load,ops
from mcm_solarcheck.services import pvis_learning_corpus as corpus
from mcm_solarcheck.services.pvis_instance_validation import preview
from mcm_solarcheck.vision.pvis_instance_decoding import aggregate
import ultralytics
root=Path('/tmp/solarcheck-public-cvut-yolo');cfg=yaml_load(Path(ultralytics.__file__).parent/'cfg/models/v8/yolov8-seg.yaml');cfg['scale']='n';cfg['nc']=1
torch.set_num_threads(2);torch.use_deterministic_algorithms(True);model=SegmentationModel(cfg,ch=3,nc=1,verbose=False).cpu().float().eval();state=torch.load(root/'cvut-rgb-yolov8n-tensors-only.pt',map_location='cpu',weights_only=True);model.load_state_dict(state,strict=True)
r=Path('/tmp/solarcheck-pvis-controlled');a=json.loads((r/'active.json').read_text());f=r/'corpora'/a['corpus_id'];manifest=json.loads((f/'corpus.json').read_text());rgb,targets=corpus.read_corpus(f,manifest)
def score(reference,masks):
 valid=reference>=0;refs=np.unique(reference[reference>0]);keep=np.any(masks[:,valid],axis=1) if len(masks) else np.zeros(0,bool);pm=masks[keep];pa=pm[:,valid].sum(axis=1);adj={};iou={}
 for rid in refs:
  inter=pm[:,reference==rid].sum(axis=1);values=inter/np.maximum(1,(reference==rid).sum()+pa-inter)
  adj[int(rid)]=sorted(np.flatnonzero(values>=.5).tolist(),key=lambda k:(-values[k],k))
  for k in adj[int(rid)]:iou[int(rid),k]=float(values[k])
 owners={}
 def match(rid,seen):
  for k in adj[rid]:
   if k in seen:continue
   seen.add(k)
   if k not in owners or match(owners[k],seen):owners[k]=rid;return True
  return False
 for rid in refs:match(int(rid),set())
 unionmask=masks.any(axis=0) if len(masks) else np.zeros(valid.shape,bool);truth=reference>0
 return dict(reference_instances=len(refs),scored_prediction_instances=len(pm),predictions_wholly_ignored=int((~keep).sum()),matched_instances=len(owners),additional_predictions=len(pm)-len(owners),missed_references=len(refs)-len(owners),foreground_intersection=int((unionmask&truth&valid).sum()),foreground_union=int(((unionmask|truth)&valid).sum()))
scores=[];rows=[];started=time.monotonic();out=root/'public-validation';out.mkdir(exist_ok=True)
with torch.inference_mode():
 for index,row in enumerate(manifest['samples']):
  if row['split']!='validation':continue
  image=cv2.resize(rgb[index],(640,640),interpolation=cv2.INTER_LINEAR);x=torch.from_numpy(image.transpose(2,0,1).copy()).float().div(255).unsqueeze(0);result=model(x);det=ops.non_max_suppression(result[0],conf_thres=.25,iou_thres=.7,nc=1,max_det=300,max_time_img=10)[0]
  if len(det):
   boxes=det[:,:4].clone()/2.5;masks=ops.process_mask_native(result[1][-1][0],det[:,6:],boxes,(256,256)).cpu().numpy().astype(bool)
   empty=~masks.any(axis=(1,2));masks=masks[~empty]
  else:masks=np.zeros((0,256,256),bool);empty=np.zeros(0,bool)
  metrics=score(targets[index],masks);scores.append(metrics);pos=len(scores);rows.append(dict(crop=pos,returned_instances=len(det),rejected_empty_masks=int(empty.sum()),**metrics));raster=np.zeros((256,256),np.int32)
  for k,m in enumerate(masks):raster[m&(raster==0)]=k+1
  preview(rgb[index],targets[index],raster,masks.any(axis=0).astype(np.float32) if len(masks) else np.zeros((256,256),np.float32)).save(out/f'preview-{pos:02d}.png')
  print(f'Public CVUT YOLO validation {pos}/24: {metrics["matched_instances"]}/{metrics["reference_instances"]} matched;{metrics["additional_predictions"]} extra',flush=True)
report=dict(check='solarcheck-cvut-yolo-public-validation-1',profile='cvut-yolov8n-rgb-unit640-conf025-nms070-retina-1',validation_crops=len(scores),instance_metrics=aggregate(scores),rows=rows,seconds=time.monotonic()-started,test_pixels_read=False,customer_images_read=False,training_started=False,production_approved=False,accuracy_verified=False)
(out/'report.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
