from pathlib import Path
from hashlib import sha256
from io import BytesIO
import zipfile,json,urllib.request
import numpy as np
from mcm_solarcheck.services.pvis_public_extra_sites import SITES,verified_zip,read_context_cache,write_context_cache
from mcm_solarcheck.services.pvis_public_context import training_sample,context_windows

def prepare_multisite(rgb,targets,manifest):
 images=[];labels=[];rows=[];records=[];summaries=[]
 for site in ('009','018','029'):
  cached=read_context_cache('/tmp/solarcheck-public-cvut-yolo/public-supplements',site) if site!='009' else None
  if cached is not None:
   for x,t,record in cached:
    images.append(x);labels.append(t);rows.append(dict(station=site,split='train',instances=len(np.unique(t[t>0]))));records.append(record)
   summaries.append(dict(station=site,images=20,crops=len(cached),instances=sum(len(np.unique(t[t>0])) for x,t,r in cached)));print('Verified numeric public subset reused',site,flush=True);continue
  if site=='009':
   path=Path('/tmp/solarcheck-pvis-verified/PVDataset_train_009.zip')
   if sha256(path.read_bytes()).hexdigest()!='f9b136c5809f37f1d714c402e642876869955598a9a4db8c3d5909a4ffa6b9fa':raise ValueError('009 identity differs')
   archive=zipfile.ZipFile(path);name=next(n for n in archive.namelist() if n.endswith('/instances.json'));coco=json.loads(archive.read(name));prefix='train/009/'
  else:
   spec=SITES[site];buffer=BytesIO();digest=sha256();received=0;reported=0
   url='https://zenodo.org/records/23886365/files/'+spec.name+'?download=1'
   with urllib.request.urlopen(url,timeout=40) as stream:
    while chunk:=stream.read(1024*1024):
     received+=len(chunk)
     if received>spec.size:raise ValueError('Public archive exceeds publisher size')
     digest.update(chunk);buffer.write(chunk)
     if received-reported>=64*1024*1024:print(f'Public training site{site}: {received//1000000}/{spec.size//1000000}MB',flush=True);reported=received
   if received!=spec.size or digest.hexdigest()!=spec.sha256:raise ValueError('Publisher full archive SHA differs')
   archive,coco=verified_zip(buffer,site);prefix=spec.prefix
   print(f'Public training site{site}: publisher SHA and COCO verified',flush=True)
  source_samples=[]
  byimage={i['id']:[] for i in coco['images']}
  for ann in coco['annotations']:byimage[ann['image_id']].append(ann)
  ordered=sorted(coco['images'],key=lambda im:sha256(f'6400:{site}:{im["id"]}'.encode()).hexdigest());count=0;crop_count=0;instance_count=0
  for image in ordered:
   anns=byimage[image['id']]
   if not anns:continue
   windows=context_windows(image,anns);name=image['file_name'];name=name if name.startswith('images/') else 'images/'+name;info=archive.getinfo(prefix+name)
   if info.file_size>16_000_000:raise ValueError('Bounded public JPEG required')
   jpeg=archive.read(info);kept=0
   for window in windows:
    try:x,t,record=training_sample(jpeg,image,anns,station=site,window=window)
    except ValueError as error:
     if 'Foreground/background lost' in str(error):continue
     raise
    n=len(np.unique(t[t>0]))
    if not 1<=n<=128:continue
    images.append(x);labels.append(t);rows.append(dict(station=site,split='train',instances=n));records.append(record);source_samples.append((x,t,record));kept+=1;crop_count+=1;instance_count+=n
   if kept:count+=1
   if count>=20:break
  archive.close()
  if site!='009':buffer.close()
  if count!=20:raise ValueError('20 eligible public images per training site required')
  if site!='009':write_context_cache('/tmp/solarcheck-public-cvut-yolo/public-supplements',site,source_samples,verified_archive=archive)
  summaries.append(dict(station=site,images=count,crops=crop_count,instances=instance_count));print('Public selected training site',json.dumps(summaries[-1]),flush=True)
 for i,row in enumerate(manifest['samples']):
  if row['split']=='validation':images.append(rgb[i]);labels.append(targets[i]);rows.append(row)
 summary=dict(check='solarcheck-pvis-multisite-crop-probe-1',train_sites=summaries,validation_site='033',validation_crops=24,crop_records_sha256=sha256(json.dumps(records,sort_keys=True,separators=(',',':')).encode()).hexdigest(),test_pixels_read=False,customer_images_read=False)
 Path('/tmp/solarcheck-public-cvut-yolo/multisite-training-crops.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary),flush=True)
 return np.stack(images),np.stack(labels),dict(manifest,samples=rows)
