from pathlib import Path
from hashlib import sha256
import zipfile,json
import numpy as np
from mcm_solarcheck.services import pvis_image_adapter as pixels
from mcm_solarcheck.services.pvis_public_training_data import training_arrays

def prepare_more(rgb,targets,manifest):
 archive=Path('/tmp/solarcheck-pvis-verified/PVDataset_train_009.zip')
 if sha256(archive.read_bytes()).hexdigest()!='f9b136c5809f37f1d714c402e642876869955598a9a4db8c3d5909a4ffa6b9fa':raise ValueError('Verified public009 archive differs')
 samples=[];images=[];labels=[];records=[]
 with zipfile.ZipFile(archive) as z:
  cname=next(n for n in z.namelist() if n.endswith('/instances.json'));prefix=cname[:-len('instances.json')];coco=json.loads(z.read(cname));annotations={im['id']:[] for im in coco['images']}
  for ann in coco['annotations']:annotations[ann['image_id']].append(ann)
  for image in sorted(coco['images'],key=lambda x:x['id']):
   anns=annotations[image['id']];width,height=image['width'],image['height'];first=pixels.crop_window(image,anns,512);windows=[first];options=set()
   for ann in anns:
    x1,y1,x2,y2=b=pixels._bounds(ann)
    if pixels._source_boundary(b,width,height) or max(x2-x1,y2-y1)>496:continue
    left=max(0,min(int(((x1+x2)/2)-256),width-512));top=max(0,min(int(((y1+y2)/2)-256),height-512));options.add((left,top,512,512))
   while len(windows)<4 and options:
    ranked=sorted(options,key=lambda w:(-min((w[0]-v[0])**2+(w[1]-v[1])**2 for v in windows),w));w=ranked[0]
    if min((w[0]-v[0])**2+(w[1]-v[1])**2 for v in windows)<512**2:break
    windows.append(w);options.remove(w)
   name=image['file_name'];name=name if name.startswith('images/') else 'images/'+name;jpeg=z.read(prefix+name)
   for window in windows:
    sample=pixels.load_sample(jpeg,image,anns,station='009',split='train',window=window);x,t=training_arrays(sample.rgb,sample.instances)
    if not sample.record['eligible']:continue
    images.append(x);labels.append(t);samples.append(dict(station='009',split='train',instances=len(np.unique(t[t>0]))));records.append(sample.record)
   print(f'Public009 source image {len(records)} verified training crops so far',flush=True)
 for i,row in enumerate(manifest['samples']):
  if row['split']=='validation':images.append(rgb[i]);labels.append(targets[i]);samples.append(row)
 summary=dict(check='solarcheck-pvis-more-crop-probe-1',policy='up_to4_farthest_whole_annotation_centers_min512_distance_per009_image',train_images=58,training_crops=sum(r['split']=='train' for r in samples),validation_crops=24,training_instances=sum(r['instances'] for r in samples if r['split']=='train'),crop_records_sha256=sha256(json.dumps(records,sort_keys=True,separators=(',',':')).encode()).hexdigest(),test_pixels_read=False,customer_images_read=False)
 Path('/tmp/solarcheck-public-cvut-yolo/more-training-crops.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary),flush=True)
 return np.stack(images),np.stack(labels),dict(manifest,samples=samples)
