from pathlib import Path
import json,time,sys
sys.path.insert(0,'/tmp')
from solarcheck_yolo_known_loss_probe import KnownPixelLoss
prefix=Path('/tmp/solarcheck_public_cvut_yolo_probe.py').read_text().split('scores=[];rows=[];started=')[0]
exec(compile(prefix,'public_yolo_probe_helpers','exec'))
from ultralytics.cfg import get_cfg
from mcm_solarcheck.services import pvis_controlled_learning as learning
from solarcheck_pvis_multisite_probe import prepare_multisite
rgb,targets,manifest=prepare_multisite(rgb,targets,manifest)
model.load_state_dict(torch.load(root/'finetune-full-more/best-head-state.pt',map_location='cpu',weights_only=True),strict=True)
model.args=get_cfg();torch.manual_seed(6400)
original={name:p.requires_grad for name,p in model.named_parameters()}
for name,p in model.named_parameters():p.requires_grad_(original[name] and int(name.split('.')[1])>=0)
for layer in model.modules():
 if isinstance(layer,torch.nn.BatchNorm2d):
  for p in layer.parameters():p.requires_grad_(False)
criterion=KnownPixelLoss(model);optimizer=torch.optim.AdamW([p for p in model.parameters() if p.requires_grad],lr=.00003,weight_decay=.0001,foreach=False)
out=Path('/tmp/solarcheck-public-cvut-yolo/finetune-multisite');out.mkdir(exist_ok=True);history=[];best=-1;best_epoch=0;start=time.monotonic();ignore_verified=True
frozen={k:v.clone() for k,v in model.state_dict().items() if 'running_' in k or 'num_batches_tracked' in k}
def batch(index,step):
 image,target=learning.augment(rgb[index],targets[index],step);image=torch.from_numpy(image.transpose(2,0,1).copy()).float().div(255).unsqueeze(0);ids=np.unique(target[target>0]);labels=np.zeros_like(target);boxes=[]
 for j,identity in enumerate(ids,1):
  y,x=np.nonzero(target==identity);labels[target==identity]=j;boxes.append([(x.min()+x.max()+1)/512,(y.min()+y.max()+1)/512,(x.max()+1-x.min())/256,(y.max()+1-y.min())/256])
 return dict(img=image,batch_idx=torch.zeros(len(ids)),cls=torch.zeros((len(ids),1)),bboxes=torch.tensor(boxes,dtype=torch.float32),masks=torch.from_numpy(labels.copy()).unsqueeze(0).float()),torch.from_numpy((target>=0).copy()).unsqueeze(0)
def evaluate():
 model.eval();results=[];rows=[]
 with torch.inference_mode():
  for i,row in enumerate(manifest['samples']):
   if row['split']!='validation':continue
   x=torch.from_numpy(rgb[i].transpose(2,0,1).copy()).float().div(255).unsqueeze(0);r=model(x);det=ops.non_max_suppression(r[0],conf_thres=.25,iou_thres=.7,nc=1,max_det=300,max_time_img=10)[0]
   masks=ops.process_mask_native(r[1][-1][0],det[:,6:],det[:,:4],(256,256)).numpy().astype(bool) if len(det) else np.zeros((0,256,256),bool);masks=masks[masks.any((1,2))];m=score(targets[i],masks);results.append(m);rows.append(dict(crop=len(rows)+1,**m))
 return aggregate(results),rows
baseline,base_rows=evaluate();print('Baseline',json.dumps(baseline),flush=True)
best=baseline['f1'];torch.save(model.state_dict(),out/'best-head-state.pt');(out/'best-metrics.json').write_text(json.dumps(dict(metrics=baseline,rows=base_rows),indent=2))
for epoch in range(10):
 losses=[]
 for position,index in enumerate(np.random.default_rng(6400+epoch).permutation([i for i,r in enumerate(manifest['samples']) if r['split']=='train'])):
  step=epoch*sum(r['split']=='train' for r in manifest['samples'])+position;model.eval();model.model[-1].train()
  for layer in model.modules():
   if isinstance(layer,torch.nn.BatchNorm2d):layer.eval()
  optimizer.zero_grad(set_to_none=True);b,valid=batch(index,step);pred=model(b['img']);grids=criterion.known(valid,pred)
  for f in pred[0]:f.retain_grad()
  pred[1].retain_grad();pred[2].retain_grad();loss,parts=criterion(pred,b);loss.backward()
  for feature,known in zip(pred[0],grids):
   if torch.any(feature.grad.masked_select(~known.expand_as(feature))!=0):raise ValueError('Unknown anchor gradient')
  if torch.any(pred[1].grad.masked_select(~criterion.known_anchors[:,None].expand_as(pred[1]))!=0):raise ValueError('Unknown coefficient gradient')
  if torch.any(pred[2].grad.masked_select(~criterion.known_proto[None,None].expand_as(pred[2]))!=0):raise ValueError('Unknown prototype gradient')
  torch.nn.utils.clip_grad_norm_([p for p in model.parameters() if p.requires_grad],10,error_if_nonfinite=True);optimizer.step();losses.append(float(loss.detach()))
  if (position+1)%20==0:print(f'Public pretrained head epoch{epoch+1}: {position+1}/76',flush=True)
 metrics,rows=evaluate();history.append(dict(epoch=epoch+1,training_loss=float(np.mean(losses)),validation=metrics));print('Epoch',epoch+1,json.dumps(history[-1]),flush=True)
 if metrics['f1']>best:
  best=metrics['f1'];best_epoch=epoch+1;torch.save(model.state_dict(),out/'best-head-state.pt');(out/'best-metrics.json').write_text(json.dumps(dict(metrics=metrics,rows=rows),indent=2))
for k,v in frozen.items():
 if not torch.equal(v,model.state_dict()[k]):raise ValueError('Frozen feature extractor or BatchNorm changed')
report=dict(check='solarcheck-public-pretrained-head-training-1',baseline=baseline,history=history,best_epoch=best_epoch,ignore_gradient_verified=True,frozen_batchnorm_verified=True,batchnorm_statistics_frozen=True,steps=10*sum(r['split']=='train' for r in manifest['samples']),elapsed_seconds=time.monotonic()-start,customer_images_read=False,test_pixels_read=False,production_approved=False)
(out/'report.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
