from pathlib import Path
from hashlib import sha256
import json,numpy as np,cv2,torch,ultralytics
from ultralytics.nn.tasks import SegmentationModel
from ultralytics.utils import yaml_load
root=Path('/tmp/solarcheck-public-cvut-yolo');cfg=yaml_load(Path(ultralytics.__file__).parent/'cfg/models/v8/yolov8-seg.yaml');cfg.update(scale='n',nc=1);torch.set_num_threads(2);torch.use_deterministic_algorithms(True)
model=SegmentationModel(cfg,ch=3,nc=1,verbose=False).cpu().float().eval();p=root/'finetune-full-more/best-head-state.pt';model.load_state_dict(torch.load(p,map_location='cpu',weights_only=True),strict=True);head=model.model[-1];head.export=True;head.format='onnx';head.dynamic=False
x=torch.zeros((1,3,256,256));out=root/'cvut-pvis-rgb-experimental.onnx'
with torch.inference_mode():
 model(x)
 torch.onnx.export(model,x,out,input_names=['images'],output_names=['output0','output1'],opset_version=12,do_constant_folding=True,dynamo=False)
net=cv2.dnn.readNetFromONNX(str(out));net.setPreferableBackend(cv2.dnn.DNN_BACKEND_OPENCV);net.setPreferableTarget(cv2.dnn.DNN_TARGET_CPU)
rng=np.random.default_rng(6400);checks=[]
with torch.inference_mode():
 for source in (np.zeros((1,3,256,256),np.float32),rng.random((1,3,256,256),dtype=np.float32)):
  expected=[v.numpy() for v in model(torch.from_numpy(source))];net.setInput(source);actual=net.forward(['output0','output1']);errors=[float(np.max(np.abs(a-b))) for a,b in zip(expected,actual)];checks.append(errors)
  if not all(a.shape==b.shape and np.allclose(a,b,rtol=.0002,atol=.0002) for a,b in zip(expected,actual)):raise ValueError('ONNX differs from strict pretrained reference')
report=dict(check='solarcheck-cvut-yolo-onnx-export-1',bytes=out.stat().st_size,sha256=sha256(out.read_bytes()).hexdigest(),input_shape=[1,3,256,256],outputs=[list(a.shape) for a in actual],max_absolute_errors=checks,reference_torch=torch.__version__,opencv=cv2.__version__,weights_source_sha256=sha256(p.read_bytes()).hexdigest(),production_approved=False)
(root/'onnx-export-report.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
