import torch
import torch.nn.functional as F
from ultralytics.utils.loss import v8SegmentationLoss
from ultralytics.utils import ops
class KnownPixelLoss(v8SegmentationLoss):
 def __init__(self,model):
  super().__init__(model); original=self.assigner; owner=self
  class KnownBCE(torch.nn.Module):
   def forward(self,scores,targets):return F.binary_cross_entropy_with_logits(scores,targets,reduction='none')*owner.known_anchors.unsqueeze(-1)
  class KnownAssigner:
   def __call__(self,scores,*args):
    result=list(original(scores*owner.known_anchors.unsqueeze(-1),*args));result[2]=result[2]*owner.known_anchors.unsqueeze(-1);result[3]=result[3]&owner.known_anchors;return tuple(result)
  self.bce=KnownBCE();self.assigner=KnownAssigner()
 def known(self,valid,predictions):
  feats,coeff,proto=predictions
  if valid.shape[0]!=1:raise ValueError('Bounded single-image loss required')
  x=valid[:,None].float();self.known_proto=F.adaptive_avg_pool2d(x,proto.shape[-2:]).eq(1)[0,0]
  self.known_anchors=torch.cat([F.adaptive_avg_pool2d(x,f.shape[-2:]).eq(1).flatten(1) for f in feats],dim=1)
  return [F.adaptive_avg_pool2d(x,f.shape[-2:]).eq(1) for f in feats]
 def single_mask_loss(self,gt_mask,pred,proto,xyxy,area):
  logits=torch.einsum('in,nhw->ihw',pred,proto);loss=F.binary_cross_entropy_with_logits(logits,gt_mask,reduction='none');known=ops.crop_mask(self.known_proto.expand_as(loss).float(),xyxy)
  return ((loss*known).sum((1,2))/known.sum((1,2)).clamp_min(1)).sum()
