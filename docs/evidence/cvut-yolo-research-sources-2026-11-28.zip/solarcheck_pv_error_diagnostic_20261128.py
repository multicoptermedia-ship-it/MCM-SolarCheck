from pathlib import Path
import json,hashlib
import torch,numpy as np
from PIL import Image,ImageDraw,ImageFont
from mcm_solarcheck.services import pvis_learning_corpus as corpus
from mcm_solarcheck.vision import cvut_yolo_research as ref
from mcm_solarcheck.vision import cvut_yolo_validation as scoring
from mcm_solarcheck.vision.cvut_yolo_outlines import projective_outlines
from mcm_solarcheck.vision.pvis_instance_decoding import aggregate
out=Path('/tmp/solarcheck-pv-errors-20261128');out.mkdir(exist_ok=True)
r=Path('/workspace/work/solarcheck-cvut-yolo-research-20261127');w=r/'PUBLIC_RESEARCH_ONLY_NOT_A_RELEASED_MODEL.pt';assert hashlib.sha256(w.read_bytes()).hexdigest()=='d80be7a0629da05e4f315e3a8ead0fb2438649c191a123a33e14403a334cdc27'
ref.published_rgb_state((r/'cvut-rgb-yolov8n-published.pt').read_bytes(),torch);model=ref.reference_model(torch,torch.load(w,map_location='cpu',weights_only=True));torch.set_num_threads(2);torch.use_deterministic_algorithms(True)
f=Path('/tmp/solarcheck-pvis-controlled/corpora/49c1a9fd81f4854fbc3e6a2fb19c921166be9725763ebc520101e6839a9cb8af');m=json.loads((f/'corpus.json').read_text());rgb,labels=corpus.read_corpus(f,m);rows=[];panels=[]
font=ImageFont.load_default(size=14)
for index,row in enumerate(m['samples']):
 if row['split']!='validation':continue
 boxes,masks,scores=scoring.infer(torch,model,rgb[index]);quads,detections,diagnostics=projective_outlines(boxes,masks,scores);target=labels[index];valid=target>=0;ids=np.unique(target[target>0]);ious={};adj={}
 for identity in ids:
  inter=quads[:,target==identity].sum(axis=1);iou=inter/np.maximum(1,(target==identity).sum()+quads[:,valid].sum(axis=1)-inter);ious[int(identity)]=iou;adj[int(identity)]=sorted(np.flatnonzero(iou>=.5).tolist(),key=lambda k:(-iou[k],k))
 owners={}
 def match(identity,seen):
  for k in adj[identity]:
   if k in seen:continue
   seen.add(k)
   if k not in owners or match(owners[k],seen):owners[k]=identity;return True
  return False
 for identity in ids:match(int(identity),set())
 pred=[]
 for k,(quad,det) in enumerate(zip(quads,detections)):
  area=int(quad[valid].sum());best=max((float(ious[int(identity)][k]) for identity in ids),default=0.)
  pred.append(dict(confidence=det.confidence,known_pixels=area,matched=k in owners,best_iou=best,known_foreground_overlap=int((quad&(target>0)).sum()),polygon=[list(p) for p in det.polygon_px]))
 metric=scoring.score_masks(target,quads);rows.append(dict(crop=len(rows)+1,metrics=metric,predictions=pred,diagnostics=diagnostics))
 panes=[Image.fromarray(rgb[index]).resize((512,512),Image.Resampling.NEAREST) for _ in range(3)]
 a=np.array(panes[1]);unknown=np.repeat(np.repeat(target<0,2,axis=0),2,axis=1);a[unknown]=(.5*a[unknown]+.5*np.array([255,0,255])).astype(np.uint8);panes[1]=Image.fromarray(a)
 for identity in ids:
  import cv2
  contours,_=cv2.findContours((target==identity).astype(np.uint8),cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_SIMPLE)
  for contour in contours:
   points=[(int(p[0][0]*2),int(p[0][1]*2)) for p in contour];ImageDraw.Draw(panes[1]).line(points+[points[0]],fill=(255,220,0),width=2)
 for k,det in enumerate(detections):
  pts=[(float(x*2),float(y*2)) for x,y in det.polygon_px];d=ImageDraw.Draw(panes[2]);d.line(pts+[pts[0]],fill=(0,255,220),width=2);x=sum(p[0] for p in pts)/4;y=sum(p[1] for p in pts)/4;d.text((x,y),f'{k+1}:{det.confidence:.2f}',fill=(255,80,20),font=font,stroke_width=1,stroke_fill='black')
 sheet=Image.new('RGB',(1536,568),'white');d=ImageDraw.Draw(sheet)
 for j,title in enumerate(('Oeffentliches RGB','REFERENZ - KEIN KI-ERGEBNIS','KI - UNGEPRUEFTE VORSCHLAEGE')):d.text((j*512+4,4),title,fill='black',font=font);sheet.paste(panes[j],(j*512,28))
 d.text((4,544),f'Crop {len(rows)} | Referenz {metric["reference_instances"]} | Treffer {metric["matched_instances"]} | zusaetzlich {metric["additional_predictions"]} | fehlend {metric["missed_references"]}',fill='black',font=font);panels.append(sheet)
result=dict(check='solarcheck-public-error-diagnostic-20261128',baseline=aggregate([r['metrics'] for r in rows]),rows=rows,customer_images_read=False,test_pixels_read=False,training_started=False,production_approved=False)
(out/'counts.json').write_text(json.dumps(result,indent=2));worst=sorted(range(len(rows)),key=lambda i:(rows[i]['metrics']['matched_instances']/(rows[i]['metrics']['reference_instances']+rows[i]['metrics']['additional_predictions']),i))[:4]
for i in worst:panels[i].save(out/f'case-{i+1:02d}.png')
matched=[p['confidence'] for row in rows for p in row['predictions'] if p['matched']];extra=[p['confidence'] for row in rows for p in row['predictions'] if not p['matched'] and p['known_pixels']]
print(json.dumps(dict(baseline=result['baseline'],worst_crops=[i+1 for i in worst],matched_confidence_quantiles=np.quantile(matched,[0,.25,.5,.75,1]).tolist(),extra_confidence_quantiles=np.quantile(extra,[0,.25,.5,.75,1]).tolist(),extra_no_foreground=sum(p['known_foreground_overlap']==0 for row in rows for p in row['predictions'] if not p['matched'] and p['known_pixels']),extra_partial_reference=sum(p['known_foreground_overlap']>0 for row in rows for p in row['predictions'] if not p['matched'] and p['known_pixels'])),indent=2))
