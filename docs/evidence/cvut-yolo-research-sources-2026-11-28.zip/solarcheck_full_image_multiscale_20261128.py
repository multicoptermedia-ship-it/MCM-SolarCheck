from pathlib import Path
from hashlib import sha256
from io import BytesIO,StringIO
from contextlib import redirect_stdout
import sys,json,time,zipfile
import cv2,numpy as np,torch
from PIL import Image
from pycocotools.coco import COCO
from pycocotools.cocoeval import COCOeval
from pycocotools import mask as maskutil
sys.path.insert(0,'/workspace/work/MCM-SolarCheck/scripts')
import MCM_SolarCheck_PVIS_REFERENZ as reference_source
from mcm_solarcheck.services.pvis_public_training_data import fingerprint
from mcm_solarcheck.vision import cvut_yolo_research as reference,cvut_yolo_validation as inference
from mcm_solarcheck.vision.cvut_yolo_outlines import projective_outlines
from mcm_solarcheck.vision.module_tiles import detect_tiles
from mcm_solarcheck.vision.module_quality import filter_module_detections
from mcm_solarcheck.vision.detection import ModuleDetection
root=Path('/workspace/work/solarcheck-cvut-yolo-research-20261127');source=Path('/tmp/solarcheck-pvis-verified')/reference_source.VALIDATION.name
reference_source.inspect_station(source,reference_source.VALIDATION)
folder=Path('/tmp/solarcheck-pvis-controlled/corpora/49c1a9fd81f4854fbc3e6a2fb19c921166be9725763ebc520101e6839a9cb8af');manifest=json.loads((folder/'corpus.json').read_text());selected={row['sample_id']:i+1 for i,row in enumerate([r for r in manifest['samples'] if r['split']=='validation'])};cases={14,17,18};reports=[]
models=[('parent',root/'PUBLIC_RESEARCH_ONLY_NOT_A_RELEASED_MODEL.pt','d80be7a0629da05e4f315e3a8ead0fb2438649c191a123a33e14403a334cdc27'),('focused',Path('/tmp/solarcheck-yolo-focused-anchor-20261128/candidate.pt'),'538633a36e44d6c3ba7176954a9d3634a2bde9da68fe6e870c1baf972707d87d')]
reference.published_rgb_state((root/'cvut-rgb-yolov8n-published.pt').read_bytes(),torch);torch.set_num_threads(2);torch.use_deterministic_algorithms(True)
with zipfile.ZipFile(source) as archive:
 coco=json.loads(archive.read(reference_source.VALIDATION.prefix+'instances.json'));annotations={im['id']:[] for im in coco['images']}
 for annotation in coco['annotations']:annotations[annotation['image_id']].append(annotation)
 images=[(selected[fingerprint(dict(station='033',image_id=image['id']))],image) for image in coco['images'] if selected.get(fingerprint(dict(station='033',image_id=image['id']))) in cases];images.sort()
 for label,path,expected in models:
  assert sha256(path.read_bytes()).hexdigest()==expected;model=reference.reference_model(torch,torch.load(path,map_location='cpu',weights_only=True))
  for case,image in images:
   name=image['file_name'];name=name if name.startswith('images/') else 'images/'+name
   with Image.open(BytesIO(archive.read(reference_source.VALIDATION.prefix+name))) as photo:
    assert photo.mode=='RGB' and photo.size==(image['width'],image['height']);rgb=np.array(photo)
   height,width=rgb.shape[:2];started=time.monotonic();cache={};nn=[0]
   def detector(pixels):
    key=sha256(pixels.tobytes()).digest()
    if key not in cache:
     boxes,masks,scores=inference.infer(torch,model,pixels);_,detections,_=projective_outlines(boxes,masks,scores);cache[key]=detections;nn[0]+=1
    return cache[key]
   side=max(width,height);square=np.zeros((side,side,3),np.uint8);square[:height,:width]=rgb;small=cv2.resize(square,(256,256),interpolation=cv2.INTER_AREA);local=detector(small);scale=side/256
   single=tuple(ModuleDetection(tuple(((x+.5)*scale-.5,(y+.5)*scale-.5) for x,y in d.polygon_px),d.confidence) for d in local);single=filter_module_detections(single,width,height,duplicate_iou=.5,minimum_area_fraction=16/(width*height),maximum_area_fraction=1.);del square
   def progress(done,total):
    if done%60==0:print(f'{label} public case{case}: {done}/{total} native tiles',flush=True)
   profiles=[]
   for name,sizes,metric in [('grid512_iou',(512,),'iou'),('grid1024_iou',(1024,),'iou'),('multiscale_iou',(1024,512),'iou'),('multiscale_ios',(1024,512),'ios')]:
    tiled,diag=detect_tiles(rgb,detector,sizes=sizes,progress=progress,duplicate_metric=metric)
    profiles.append((name,tiled,diag))
   ground=dict(info={},images=[image],categories=coco['categories'],annotations=annotations[image['id']])
   metrics={}
   for method,detections in [('whole_image256',single)]+[(name,dets) for name,dets,_ in profiles]:
    predictions=[]
    for d in detections:
     coords=[float(v+.5) for point in d.polygon_px for v in point];rle=maskutil.merge(maskutil.frPyObjects([coords],height,width));predictions.append(dict(image_id=image['id'],category_id=coco['categories'][0]['id'],score=d.confidence,segmentation=rle))
    with redirect_stdout(StringIO()):
     gt=COCO();gt.dataset=ground;gt.createIndex()
     if predictions:dt=gt.loadRes(predictions)
     else:dt=COCO();dt.dataset=dict(images=[image],categories=coco['categories'],annotations=[]);dt.createIndex()
     evaluator=COCOeval(gt,dt,'segm');evaluator.params.imgIds=[image['id']];evaluator.params.iouThrs=np.array([.5,.75]);evaluator.params.maxDets=[1,100,5000];evaluator.evaluate();evaluator.accumulate()
    record={}
    for t,key in enumerate(('iou050','iou075')):
     item=next(x for x in evaluator.evalImgs if x is not None and x['aRng']==evaluator.params.areaRng[0]);matches=item['dtMatches'][t];ignore=item['dtIgnore'][t];tp=int(((matches>0)&~ignore).sum());fp=int(((matches==0)&~ignore).sum());n=int((item['gtIgnore']==0).sum());precision=evaluator.eval['precision'][t,:,0,0,-1];ap=float(precision[precision>=0].mean()) if np.any(precision>=0) else None
     record[key]=dict(reference_instances=n,predictions=len(predictions),matched_instances=tp,additional_predictions=fp,missed_references=n-tp,AP=ap)
    metrics[method]=record
   reports.append(dict(model=label,weights_sha256=expected,public_case=case,width=width,height=height,metrics=metrics,profiles={name:dict(diagnostics=diag,proposals=[dict(polygon_px=d.polygon_px,confidence=d.confidence) for d in dets]) for name,dets,diag in profiles},model_windows_computed=nn[0],seconds=time.monotonic()-started));print('Public full-image result',json.dumps({k:v for k,v in reports[-1].items() if k!='profiles'}),flush=True)
   Path('/tmp/solarcheck-full-image-multiscale-20261128.progress.json').write_text(json.dumps(dict(rows=reports),indent=2))
result=dict(check='solarcheck-public-full-image-multiscale-probe-1',source_archive_sha256=reference_source.VALIDATION.sha256,source_station='033',fixed_public_cases=sorted(cases),evaluation='pycocotools2.0.10_coco_segmentation_iou050_and075_maxdet5000',rows=reports,training_started=False,customer_images_read=False,test_pixels_read=False,accuracy_verified=False,coverage_verified=False,production_approved=False)
Path('/tmp/solarcheck-full-image-multiscale-20261128.json').write_text(json.dumps(result,indent=2));print('Full-image comparison complete',flush=True)
