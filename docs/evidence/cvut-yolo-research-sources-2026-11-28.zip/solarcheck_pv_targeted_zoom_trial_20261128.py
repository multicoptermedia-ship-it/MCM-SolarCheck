from pathlib import Path
from hashlib import sha256
from collections import Counter
import json,time,zipfile,os
import torch,numpy as np
from ultralytics.cfg import get_cfg
from mcm_solarcheck.vision import cvut_yolo_research as reference,cvut_yolo_validation as scoring
from mcm_solarcheck.vision.cvut_yolo_outlines import projective_outlines
from mcm_solarcheck.vision.pvis_instance_decoding import aggregate
from mcm_solarcheck.services import pvis_learning_corpus as corpus,pvis_public_extra_sites as extra,pvis_public_context as context,pvis_yolo_training_targets as policy,pvis_controlled_learning as rotation
root=Path('/workspace/work/solarcheck-cvut-yolo-research-20261127');parent=root/'PUBLIC_RESEARCH_ONLY_NOT_A_RELEASED_MODEL.pt';parent_sha=sha256(parent.read_bytes()).hexdigest();assert parent_sha=='d80be7a0629da05e4f315e3a8ead0fb2438649c191a123a33e14403a334cdc27'
output=Path('/tmp/solarcheck-yolo-targeted-zoom-20261128');output.mkdir(exist_ok=False)
train=[];records=[]
source=Path('/tmp/solarcheck-pvis-verified/PVDataset_train_009.zip');assert sha256(source.read_bytes()).hexdigest()=='f9b136c5809f37f1d714c402e642876869955598a9a4db8c3d5909a4ffa6b9fa'
with zipfile.ZipFile(source) as archive:
 coco=json.loads(archive.read('train/009/instances.json'));anns={im['id']:[] for im in coco['images']}
 for annotation in coco['annotations']:anns[annotation['image_id']].append(annotation)
 images=sorted(coco['images'],key=lambda im:sha256(f'6400:009:{im["id"]}'.encode()).hexdigest());accepted=0
 for image in images:
  if not anns[image['id']]:continue
  name=image['file_name'];name=name if name.startswith('images/') else 'images/'+name;payload=archive.read('train/009/'+name);kept=0
  for window in context.context_windows(image,anns[image['id']]):
   try:rgb,target,record=context.training_sample(payload,image,anns[image['id']],station='009',window=window)
   except ValueError as error:
    if 'Foreground/background lost' in str(error):continue
    raise
   if not 1<=len(np.unique(target[target>0]))<=128:continue
   train.append((rgb,target));records.append(record);kept+=1
  accepted+=bool(kept)
  if accepted==20:break
for site in ('018','029'):
 cached=extra.read_context_cache('/tmp/solarcheck-public-cvut-yolo/public-supplements',site)
 if cached is None:raise ValueError('Existing verified numeric subset required, no redownload')
 for rgb,target,record in cached:train.append((rgb,target));records.append(record)
dataset_sha=sha256(json.dumps(records,sort_keys=True,separators=(',',':')).encode()).hexdigest();assert dataset_sha=='93176bd7dd0ee84487c8f807a19a63ccfb5d54afa8b7998c512e6615cf2aed27';assert len(train)==232
folder=Path('/tmp/solarcheck-pvis-controlled/corpora/49c1a9fd81f4854fbc3e6a2fb19c921166be9725763ebc520101e6839a9cb8af');manifest=json.loads((folder/'corpus.json').read_text());rgb,targets=corpus.read_corpus(folder,manifest);validation=[(rgb[i],targets[i]) for i,r in enumerate(manifest['samples']) if r['split']=='validation'];assert len(validation)==24
reference.published_rgb_state((root/'cvut-rgb-yolov8n-published.pt').read_bytes(),torch);model=reference.reference_model(torch,torch.load(parent,map_location='cpu',weights_only=True));model.args=get_cfg();torch.manual_seed(6400);torch.set_num_threads(2);torch.use_deterministic_algorithms(True);reference.configure_public_training(torch,model,0)
criterion=reference.known_pixel_loss(torch,model);optimizer=torch.optim.AdamW([p for p in model.parameters() if p.requires_grad],lr=.0001,weight_decay=.0001,foreach=False);frozen={k:v.clone() for k,v in model.state_dict().items() if 'running_' in k or 'num_batches_tracked' in k or '.dfl.' in k}
def score75(target,masks):
 valid=target>=0;ids=np.unique(target[target>0]);keep=masks[:,valid].any(1);masks=masks[keep];area=masks[:,valid].sum(1);adj={}
 for identity in ids:
  intersection=masks[:,target==identity].sum(1);v=intersection/np.maximum(1,(target==identity).sum()+area-intersection);adj[int(identity)]=sorted(np.flatnonzero(v>=.75).tolist(),key=lambda k:(-v[k],k))
 owners={}
 def visit(identity,seen):
  for k in adj[identity]:
   if k in seen:continue
   seen.add(k)
   if k not in owners or visit(owners[k],seen):owners[k]=identity;return True
  return False
 for identity in ids:visit(int(identity),set())
 return dict(reference_instances=len(ids),scored_prediction_instances=len(masks),predictions_wholly_ignored=int((~keep).sum()),matched_instances=len(owners),additional_predictions=len(masks)-len(owners),missed_references=len(ids)-len(owners),foreground_intersection=0,foreground_union=0)
def evaluate():
 rows=[]
 for image,target in validation:
  boxes,masks,scores=scoring.infer(torch,model,image);quads,_,diagnostics=projective_outlines(boxes,masks,scores);rows.append(dict(iou050=scoring.score_masks(target,quads),iou075=score75(target,quads)))
 return {key:aggregate([r[key] for r in rows]) for key in ('iou050','iou075')}
def save_state():
 temporary=output/'candidate.next.pt'
 try:torch.save(model.state_dict(),temporary);temporary.replace(output/'candidate.pt')
 finally:temporary.unlink(missing_ok=True)
def batch(image,target):
 ids=np.unique(target[target>0]);labels=np.zeros_like(target);boxes=[]
 for j,identity in enumerate(ids,1):
  y,x=np.nonzero(target==identity);labels[target==identity]=j;boxes.append([(x.min()+x.max()+1)/512,(y.min()+y.max()+1)/512,(x.max()+1-x.min())/256,(y.max()+1-y.min())/256])
 return dict(img=torch.from_numpy(image.transpose(2,0,1).copy()).float().div(255).unsqueeze(0),batch_idx=torch.zeros(len(ids)),cls=torch.zeros((len(ids),1)),bboxes=torch.tensor(boxes,dtype=torch.float32),masks=torch.from_numpy(labels).float().unsqueeze(0),valid_pixels=torch.from_numpy((target>=0).copy()).unsqueeze(0))
baseline=evaluate();print('Baseline',json.dumps(baseline),flush=True);best=(baseline['iou075']['f1'],baseline['iou050']['f1']);best_epoch=0;history=[];counts=Counter();steps=0;started=time.monotonic()
for epoch in range(12):
 losses=[]
 for pos,index in enumerate(np.random.default_rng(6400+epoch).permutation(len(train))):
  step=epoch*len(train)+pos;image,target,info=policy.prepare(*train[index],step)
  for key in ('zoomed','partial_instances_ignored','unsupported_instances_ignored'):counts[key]+=info[key]
  if not info['eligible']:counts['ineligible']+=1;continue
  image,target=rotation.augment(image,target,step);b=batch(image,target);reference.public_training_mode(torch,model);optimizer.zero_grad(set_to_none=True);pred=model(b['img'])
  for x in (*pred[0],pred[1],pred[2]):x.retain_grad()
  loss,_=criterion(pred,b);loss.backward()
  for feature,known in zip(pred[0],criterion.known_grids):
   if torch.any(feature.grad.masked_select(~known.expand_as(feature))!=0):raise ValueError('Unknown anchor gradient')
  if torch.any(pred[1].grad.masked_select(~criterion.known_anchors[:,None].expand_as(pred[1]))!=0):raise ValueError('Unknown coefficient gradient')
  if torch.any(pred[2].grad.masked_select(~criterion.known_proto[None,None].expand_as(pred[2]))!=0):raise ValueError('Unknown prototype gradient')
  torch.nn.utils.clip_grad_norm_([p for p in model.parameters() if p.requires_grad],10,error_if_nonfinite=True);optimizer.step();steps+=1;losses.append(float(loss.detach()))
  if (pos+1)%60==0:print(f'Public targeted epoch {epoch+1}/12: {pos+1}/232',flush=True)
 if (epoch+1)%3==0:
  metrics=evaluate();history.append(dict(epoch=epoch+1,loss=float(np.mean(losses)),validation=metrics));print('Validation',json.dumps(history[-1]),flush=True);quality=(metrics['iou075']['f1'],metrics['iou050']['f1'])
  if quality>best:best=quality;best_epoch=epoch+1;save_state()
for name,value in frozen.items():
 if not torch.equal(value,model.state_dict()[name]):raise ValueError('Frozen state changed')
assert sha256(parent.read_bytes()).hexdigest()==parent_sha
selected=None
if best_epoch:
 state=torch.load(output/'candidate.pt',map_location='cpu',weights_only=True);model=reference.reference_model(torch,state);selected=evaluate()
report=dict(check='solarcheck-public-targeted-zoom-trial-1',parent_sha256=parent_sha,dataset_sha256=dataset_sha,profile=policy.PROFILE,policy_source_sha256=sha256(Path(policy.__file__).read_bytes()).hexdigest(),trainer_source_sha256=sha256(Path(__file__).read_bytes()).hexdigest(),baseline=baseline,history=history,best_epoch=best_epoch,selected=selected,counts=dict(counts),steps=steps,elapsed_seconds=time.monotonic()-started,learning_rate=.0001,epochs=12,selection='maximum_iou075_f1_then_iou050_f1_on_same24_validation',ignore_gradient_verified=True,frozen_state_verified=True,customer_images_read=False,customer_training_started=False,test_pixels_read=False,app_model_updated=False,production_approved=False,commercial_training_approved=False,public_training_started=True,optimizer_resume_supported=False)
if best_epoch:report['candidate_sha256']=sha256((output/'candidate.pt').read_bytes()).hexdigest();report['candidate_bytes']=(output/'candidate.pt').stat().st_size
(output/'report.next.json').write_text(json.dumps(report,indent=2));(output/'report.next.json').replace(output/'report.json');print(json.dumps(report,indent=2),flush=True)
