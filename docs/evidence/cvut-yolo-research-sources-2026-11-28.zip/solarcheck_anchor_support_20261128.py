from pathlib import Path
import json
import numpy as np
from mcm_solarcheck.services import pvis_learning_corpus as corpus,pvis_public_extra_sites as extra
f=Path('/tmp/solarcheck-pvis-controlled/corpora/49c1a9fd81f4854fbc3e6a2fb19c921166be9725763ebc520101e6839a9cb8af');m=json.loads((f/'corpus.json').read_text());_,targets=corpus.read_corpus(f,m);rows=[(t,r['station']) for t,r in zip(targets,m['samples'])]
for site in ('018','029'):
 c=extra.read_context_cache('/tmp/solarcheck-public-cvut-yolo/public-supplements',site);assert c is not None;rows.extend((t,site) for _,t,_ in c)
summary={site:dict(instances=0,no_center_any_stride=0,no_fully_known_center=0,shorter_than8=0,under_half_area_known=0) for site in ('009','018','029','033')}
for target,site in rows:
 valid=target>=0;grids=[]
 for stride in (8,16,32):
  known=valid.reshape(256//stride,stride,256//stride,stride).all((1,3));y,x=np.meshgrid(np.arange(stride//2,256,stride),np.arange(stride//2,256,stride),indexing='ij');grids.append((x,y,known))
 for identity in np.unique(target[target>0]):
  y,x=np.nonzero(target==identity);left,right=x.min(),x.max()+1;top,bottom=y.min(),y.max()+1;any_center=any_known=0
  for gx,gy,known in grids:
   inside=(gx>left)&(gx<right)&(gy>top)&(gy<bottom);any_center+=inside.sum();any_known+=(inside&known).sum()
  s=summary[site];s['instances']+=1;s['no_center_any_stride']+=int(any_center==0);s['no_fully_known_center']+=int(any_known==0);s['shorter_than8']+=int(min(right-left,bottom-top)<8);s['under_half_area_known']+=int(valid[top:bottom,left:right].mean()<.5)
print(json.dumps(summary,indent=2));Path('/tmp/solarcheck-anchor-support-20261128.json').write_text(json.dumps(summary,indent=2))
