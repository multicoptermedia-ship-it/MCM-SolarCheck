from pathlib import Path
import json,hashlib
import numpy as np,torch
from mcm_solarcheck.vision import cvut_yolo_research as ref
from mcm_solarcheck.vision import cvut_yolo_validation as scoring
from mcm_solarcheck.vision.cvut_yolo_outlines import projective_outlines
from mcm_solarcheck.vision.pvis_instance_decoding import aggregate
from mcm_solarcheck.services import pvis_learning_corpus as corpus,pvis_public_extra_sites as extra
root=Path('/workspace/work/solarcheck-cvut-yolo-research-20261127');p=root/'PUBLIC_RESEARCH_ONLY_NOT_A_RELEASED_MODEL.pt';assert hashlib.sha256(p.read_bytes()).hexdigest()=='d80be7a0629da05e4f315e3a8ead0fb2438649c191a123a33e14403a334cdc27'
ref.published_rgb_state((root/'cvut-rgb-yolov8n-published.pt').read_bytes(),torch);model=ref.reference_model(torch,torch.load(p,map_location='cpu',weights_only=True));torch.set_num_threads(2);torch.use_deterministic_algorithms(True)
f=Path('/tmp/solarcheck-pvis-controlled/corpora/49c1a9fd81f4854fbc3e6a2fb19c921166be9725763ebc520101e6839a9cb8af');manifest=json.loads((f/'corpus.json').read_text());rgb,labels=corpus.read_corpus(f,manifest)
samples=[(rgb[i],labels[i],r['station'],r['split']) for i,r in enumerate(manifest['samples'])]
for station in ('018','029'):
 cache=extra.read_context_cache(Path('/tmp/solarcheck-public-cvut-yolo/public-supplements'),station)
 if cache is None:raise ValueError('Existing numeric cache required; never redownload')
 samples.extend((a,b,station,'train') for a,b,_ in cache)
rows=[]
for pos,(image,target,station,split) in enumerate(samples,1):
 boxes,masks,scores=scoring.infer(torch,model,image);quads,dets,diagnostics=projective_outlines(boxes,masks,scores);areas=quads.sum((1,2));valid=target>=0;known=quads[:,valid].sum(1);ids=np.unique(target[target>0]);table=[]
 for identity in ids:
  intersection=quads[:,target==identity].sum(1);table.append(intersection/np.maximum(1,(target==identity).sum()+known-intersection))
 table=np.asarray(table)
 def metrics(threshold=.5,selected=None):
  if selected is None:selected=list(range(len(quads)))
  own={}
  def visit(identity,seen):
   candidates=sorted((k for k in selected if known[k] and table[identity,k]>=threshold),key=lambda k:(-table[identity,k],k))
   for k in candidates:
    if k in seen:continue
    seen.add(k)
    if k not in own or visit(own[k],seen):own[k]=identity;return True
   return False
  for identity in range(len(ids)):visit(identity,set())
  return dict(reference_instances=len(ids),scored_prediction_instances=sum(known[k]>0 for k in selected),matched_instances=len(own),additional_predictions=sum(known[k]>0 for k in selected)-len(own),missed_references=len(ids)-len(own),predictions_wholly_ignored=sum(known[k]==0 for k in selected),foreground_intersection=0,foreground_union=0)
 # Fixed standard confidence probes, not a deployment threshold selection.
 confidence={str(t):metrics(selected=[k for k,d in enumerate(dets) if d.confidence>=t]) for t in (.25,.5,.75,.9)}
 # Explicit diagnostic only: candidates mostly outside known annotation support.
 supported=[k for k in range(len(quads)) if known[k]/max(1,areas[k])>=.5]
 # Standard intersection-over-smaller suppression, higher confidence first.
 kept=[]
 for k in sorted(range(len(quads)),key=lambda k:-dets[k].confidence):
  if all((quads[k]&quads[j]).sum()/max(1,min(areas[k],areas[j]))<.8 for j in kept):kept.append(k)
 rows.append(dict(station=station,split=split,baseline=metrics(),iou075=metrics(.75),confidence=confidence,majority_known_diagnostic=metrics(selected=supported),containment_diagnostic=metrics(selected=kept),known_fractions=[float(k/max(1,a)) for k,a in zip(known,areas)]))
 if pos%30==0:print(f'Public fit {pos}/{len(samples)}',flush=True)
summary={}
for station in ('009','018','029','033'):
 subset=[r for r in rows if r['station']==station];summary[station]={key:aggregate([r[key] for r in subset]) for key in ('baseline','iou075','majority_known_diagnostic','containment_diagnostic')};summary[station]['confidence']={str(t):aggregate([r['confidence'][str(t)] for r in subset]) for t in (.25,.5,.75,.9)}
Path('/tmp/solarcheck-pv-fit-20261128.json').write_text(json.dumps(dict(rows=rows,summary=summary),indent=2,default=lambda x:int(x)))
for station,values in summary.items():
 print(station,json.dumps({key:{k:v[k] for k in ('matched_instances','additional_predictions','missed_references')} for key,v in values.items() if key!='confidence'}));print('confidence',station,json.dumps({key:{k:v[k] for k in ('matched_instances','additional_predictions','missed_references')} for key,v in values['confidence'].items()}))
